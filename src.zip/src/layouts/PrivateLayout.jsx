// src/layouts/PrivateLayout.jsx
import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import Sidebar from "@/components/Sidebar";

export default function PrivateLayout({ children }) {
  const { user, loading } = useAuth() || {};
  const location = useLocation();

  // Evita parpadeos mientras se resuelve la sesión
  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center bg-white text-[#4b2e19]">
        Cargando…
      </div>
    );
  }

  // Si no hay usuario autenticado, redirige a /login y conserva origen
  if (!user) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 bg-gray-50 p-4">{children}</main>
    </div>
  );
}
