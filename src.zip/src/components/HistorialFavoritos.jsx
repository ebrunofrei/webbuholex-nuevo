// src/components/HistorialFavoritos.jsx
import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  obtenerFavoritosLitisBot,
  obtenerHistorialArchivos,
} from "@/services/firebaseLitisBotService";

export default function HistorialFavoritos() {
  const { user } = useAuth();
  const [favoritosChat, setFavoritosChat] = useState([]);
  const [favoritosArchivos, setFavoritosArchivos] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.uid) return;

    const cargarFavoritos = async () => {
      setLoading(true);
      try {
        const chats = await obtenerFavoritosLitisBot(user.uid);
        const archivos = await obtenerHistorialArchivos(user.uid);
        setFavoritosChat(chats || []);
        setFavoritosArchivos((archivos || []).filter((a) => a.favorito));
      } catch (err) {
        console.error("Error cargando favoritos:", err);
      }
      setLoading(false);
    };

    cargarFavoritos();
  }, [user]);

  const filtradosChat = favoritosChat.filter((f) =>
    f.content?.toLowerCase().includes(busqueda.toLowerCase())
  );
  const filtradosArchivos = favoritosArchivos.filter((f) =>
    f.nombre?.toLowerCase().includes(busqueda.toLowerCase())
  );

  const exportarFavoritos = () => {
    const data = [
      "=== Favoritos de LitisBot ===",
      ...filtradosChat.map(
        (m) => `[${m.role === "assistant" ? "LitisBot" : "Tú"}] ${m.content}`
      ),
      "",
      "=== Archivos Favoritos ===",
      ...filtradosArchivos.map((a) => `📂 ${a.nombre} (${a.tipo || "archivo"})`),
    ];

    const blob = new Blob([data.join("\n\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "favoritos-litisbot.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-3xl mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold text-[#b03a1a] mb-4">
        ⭐ Favoritos de LitisBot
      </h1>

      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <input
          type="text"
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
          placeholder="Buscar en chats o archivos favoritos..."
          className="flex-1 border px-3 py-2 rounded text-[#4b2e19]"
        />
        <button
          onClick={exportarFavoritos}
          className="bg-[#b03a1a] text-white rounded-xl px-6 py-2 font-bold hover:bg-[#8d2a12] transition"
        >
          Exportar
        </button>
      </div>

      {loading && (
        <div className="text-[#b03a1a] font-bold my-6">Cargando favoritos...</div>
      )}

      {!loading && filtradosChat.length === 0 && filtradosArchivos.length === 0 && (
        <div className="text-[#4b2e19] my-6">No tienes favoritos guardados.</div>
      )}

      {/* Favoritos de chat */}
      {filtradosChat.length > 0 && (
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-[#4b2e19] mb-3">
            💬 Chats favoritos
          </h2>
          <div className="space-y-4">
            {filtradosChat.map((msg, i) => (
              <div
                key={msg.id || i}
                className={`p-4 rounded-xl shadow border ${
                  msg.role === "assistant"
                    ? "bg-white border-[#e5c9b2]"
                    : "bg-[#fde7e7] border-[#b03a1a]"
                }`}
              >
                <div className="font-semibold text-[#4b2e19] mb-1">
                  {msg.role === "assistant" ? "🦉 LitisBot" : "👤 Tú"}
                </div>
                <div className="whitespace-pre-line text-[#4b2e19]">
                  {msg.content}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Favoritos de archivos */}
      {filtradosArchivos.length > 0 && (
        <section>
          <h2 className="text-xl font-semibold text-[#4b2e19] mb-3">
            📂 Archivos favoritos
          </h2>
          <div className="space-y-2">
            {filtradosArchivos.map((a, i) => (
              <div
                key={a.id || i}
                className="flex items-center gap-3 border p-3 rounded-lg shadow-sm bg-white"
              >
                <span className="text-2xl">📄</span>
                <div className="flex-1">
                  <div className="font-medium text-[#4b2e19]">{a.nombre}</div>
                  <div className="text-sm text-gray-500">
                    {a.tipo || "Archivo"} – {a.fecha || "sin fecha"}
                  </div>
                </div>
                {a.url && (
                  <a
                    href={a.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#b03a1a] font-bold hover:underline"
                  >
                    Ver
                  </a>
                )}
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
