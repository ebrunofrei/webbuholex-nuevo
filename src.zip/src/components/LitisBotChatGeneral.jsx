// src/components/LitisBotChatGeneral.jsx
import LitisBotChatBase from "./LitisBotChatBase";
export default function LitisBotChatGeneral() {
  return <LitisBotChatBase modo="general" />;
}
