// src/firebase.js
import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getFirestore, doc, getDoc, setDoc, collection, query, where,
  getDocs, updateDoc, addDoc, arrayUnion, arrayRemove, deleteDoc,
  onSnapshot, Timestamp, serverTimestamp, orderBy, limit, startAfter,
} from "firebase/firestore";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import {
  getStorage, ref, uploadBytes, deleteObject, getDownloadURL,
} from "firebase/storage";
import {
  getMessaging, isSupported, getToken, onMessage,
} from "firebase/messaging";

/* ---------------------------
   Helpers
---------------------------- */
// Extrae variables de entorno de forma segura
const getEnv = (key) => {
  if (typeof import.meta !== "undefined" && import.meta.env?.[key]) {
    return import.meta.env[key];
  }
  if (typeof process !== "undefined" && process.env?.[key]) {
    return process.env[key];
  }
  return undefined;
};

/* ---------------------------
   Configuración Firebase
---------------------------- */
const firebaseConfig = {
  apiKey:            getEnv("VITE_FIREBASE_API_KEY"),
  authDomain:        getEnv("VITE_FIREBASE_AUTH_DOMAIN"),
  projectId:         getEnv("VITE_FIREBASE_PROJECT_ID"),
  storageBucket:     getEnv("VITE_FIREBASE_STORAGE_BUCKET"),
  messagingSenderId: getEnv("VITE_FIREBASE_MESSAGING_SENDER_ID"),
  appId:             getEnv("VITE_FIREBASE_APP_ID"),
  measurementId:     getEnv("VITE_FIREBASE_MEASUREMENT_ID"),
};

const HAS_CORE =
  Boolean(firebaseConfig.apiKey) &&
  Boolean(firebaseConfig.projectId) &&
  Boolean(firebaseConfig.appId);

/* ---------------------------
   Inicialización
---------------------------- */
const app = HAS_CORE
  ? (getApps().length ? getApp() : initializeApp(firebaseConfig))
  : null;

// Servicios principales
const db      = app ? getFirestore(app) : null;
const auth    = app ? getAuth(app)      : null;
const storage = app ? getStorage(app)   : null;

/* ---------------------------
   Firebase Cloud Messaging
---------------------------- */
let messaging = null;

/** Registra SW de FCM si está en /public */
export const registerFcmServiceWorker = async () => {
  try {
    if (!("serviceWorker" in navigator)) return null;
    return await navigator.serviceWorker.register("/firebase-messaging-sw.js");
  } catch (e) {
    console.warn("⚠️ FCM SW no registrado:", e);
    return null;
  }
};

/** Inicializa Messaging solo si es soportado */
export const initMessaging = async () => {
  try {
    if (!app || !HAS_CORE) return null;
    if (typeof window === "undefined") return null;
    if (!("Notification" in window)) return null;
    if (!(await isSupported())) return null;

    await registerFcmServiceWorker();
    messaging = getMessaging(app);
    console.info("✅ Firebase Messaging inicializado");
    return messaging;
  } catch (err) {
    console.error("❌ Error inicializando Messaging:", err);
    return null;
  }
};

/** Obtiene token de FCM */
export const getFcmToken = async () => {
  try {
    if (!messaging) await initMessaging();
    if (!messaging) return null;

    const vapidKey = getEnv("VITE_FIREBASE_VAPID_KEY");
    return await getToken(messaging, vapidKey ? { vapidKey } : {});
  } catch (e) {
    console.warn("⚠️ No se obtuvo token FCM:", e);
    return null;
  }
};

/** Listener de mensajes en primer plano */
export const onForegroundMessage = (cb) =>
  messaging ? onMessage(messaging, cb) : () => {};

/* ---------------------------
   Exportaciones
---------------------------- */
export {
  app,
  db,
  auth,
  storage,
  messaging, // puede ser null

  // Firestore
  doc, getDoc, setDoc, collection, query, where, getDocs, updateDoc, addDoc,
  arrayUnion, arrayRemove, deleteDoc, onSnapshot, Timestamp,
  serverTimestamp, orderBy, limit, startAfter,

  // Storage
  ref, uploadBytes, deleteObject, getDownloadURL,

  // Auth
  onAuthStateChanged,

  // Messaging base (por compatibilidad)
  getToken, onMessage,
};
