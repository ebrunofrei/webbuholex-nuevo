export default function Buzon() {
  return (
    <div className="bg-white p-6 rounded-xl shadow text-gray-400 text-center">
      Pronto: Aquí se mostrarán archivos eliminados o respaldados para restaurar o auditar.
    </div>
  );
}
