import React from "react";

export default function Bienvenida() {
  return (
    <h1 className="text-2xl font-semibold text-gray-700">
      Bienvenido a tu Oficina Virtual.
    </h1>
  );
}
