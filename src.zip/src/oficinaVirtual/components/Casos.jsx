import React from "react";

export default function Casos() {
  return (
    <p className="text-gray-700">
      Gestión de casos legales por expediente, cliente, materia y juzgado.
    </p>
  );
}
