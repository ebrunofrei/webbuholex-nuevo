// src/components/LitisBotFlotante.jsx
import React, { useState, useRef, useEffect } from "react";
import LitisBotChatBase from "@/components/LitisBotChatBase";

export default function LitisBotFlotante() {
  const [open, setOpen] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [position, setPosition] = useState({ bottom: 32, right: 32 });
  const offset = useRef({ x: 0, y: 0 });

  // 🖱️ Desktop Drag
  const handleMouseDown = (e) => {
    setDragging(true);
    offset.current = { x: e.clientX, y: e.clientY };
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
  };
  const handleMouseMove = (e) => {
    setPosition((prev) => ({
      bottom: Math.max(0, prev.bottom - (e.clientY - offset.current.y)),
      right: Math.max(0, prev.right - (e.clientX - offset.current.x)),
    }));
    offset.current = { x: e.clientX, y: e.clientY };
  };
  const handleMouseUp = () => {
    setDragging(false);
    window.removeEventListener("mousemove", handleMouseMove);
    window.removeEventListener("mouseup", handleMouseUp);
  };

  // 📱 Touch Drag
  const handleTouchStart = (e) => {
    setDragging(true);
    const touch = e.touches[0];
    offset.current = { x: touch.clientX, y: touch.clientY };
    window.addEventListener("touchmove", handleTouchMove);
    window.addEventListener("touchend", handleTouchEnd);
  };
  const handleTouchMove = (e) => {
    const touch = e.touches[0];
    setPosition((prev) => ({
      bottom: Math.max(0, prev.bottom - (touch.clientY - offset.current.y)),
      right: Math.max(0, prev.right - (touch.clientX - offset.current.x)),
    }));
    offset.current = { x: touch.clientX, y: touch.clientY };
  };
  const handleTouchEnd = () => {
    setDragging(false);
    window.removeEventListener("touchmove", handleTouchMove);
    window.removeEventListener("touchend", handleTouchEnd);
  };

  // 🧹 Limpieza global
  useEffect(() => {
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
      window.removeEventListener("touchmove", handleTouchMove);
      window.removeEventListener("touchend", handleTouchEnd);
    };
  }, []);

  return (
    <>
      {!open && (
        <button
          style={{
            position: "fixed",
            bottom: position.bottom,
            right: position.right,
            zIndex: 4000,
            width: 56,
            height: 56,
            borderRadius: "50%",
            background: "#b03a1a",
            boxShadow: "0 3px 18px #0003",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: dragging ? "grabbing" : "grab",
            color: "#fff",
            border: "none",
          }}
          onClick={() => setOpen(true)}
          onMouseDown={handleMouseDown}
          onTouchStart={handleTouchStart}
          aria-label="Abrir LitisBot"
        >
          <span style={{ fontSize: 28 }}>🦉</span>
        </button>
      )}
      {open && (
        <div
          style={{
            position: "fixed",
            bottom: position.bottom,
            right: position.right,
            zIndex: 4000,
            width: 410,
            maxWidth: "98vw",
            height: 570,
            background: "#fff",
            border: "2px solid #b03a1a",
            borderRadius: 24,
            boxShadow: "0 10px 40px #0003",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <div
            style={{
              padding: "6px 12px",
              background: "#b03a1a",
              color: "#fff",
              borderTopLeftRadius: 22,
              borderTopRightRadius: 22,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              cursor: dragging ? "grabbing" : "grab",
            }}
            onMouseDown={handleMouseDown}
            onTouchStart={handleTouchStart}
          >
            <span style={{ fontWeight: "bold" }}>LitisBot</span>
            <button
              onClick={() => setOpen(false)}
              style={{
                background: "transparent",
                border: "none",
                color: "#fff",
                fontSize: 18,
                cursor: "pointer",
              }}
              aria-label="Cerrar LitisBot"
            >
              ✕
            </button>
          </div>
          <div style={{ flex: 1, overflow: "hidden" }}>
            <LitisBotChatBase modoFlotante onClose={() => setOpen(false)} />
          </div>
        </div>
      )}
    </>
  );
}
