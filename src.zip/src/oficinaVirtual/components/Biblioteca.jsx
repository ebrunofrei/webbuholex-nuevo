import React from "react";

export default function Biblioteca() {
  return (
    <p className="text-gray-700">
      Tu biblioteca jurídica personalizada para acceder a leyes, libros y archivos legales.
    </p>
  );
}
