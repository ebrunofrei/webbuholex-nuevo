// src/oficinaVirtual/routes/OficinaVirtualRoutes.jsx
import { Routes, Route } from "react-router-dom";

// === Configuración ===
import PanelConfiguracionOficina from "@oficinaPages/configuracion/PanelConfiguracionOficina";

// === Pagos ===
import PagoPRO from "@oficinaPages/pagos/PagoPRO";
import HistorialPagos from "@oficinaPages/pagos/HistorialPagos";
import ExitUpgrade from "@oficinaPages/pagos/ExitUpgrade";

// === Noticias (especializadas en OficinaVirtual) ===
import Noticias from "@oficinaPages/Noticias";

// === Admin ===
import ConsultasAdmin from "@pages/admin/ConsultasAdmin";
import DashboardAdmin from "@pages/admin/DashboardAdmin";
import LoginAdmin from "@pages/admin/LoginAdmin";
import PublicarArticulo from "@pages/admin/PublicarArticulo";
import ServiciosAdmin from "@pages/admin/ServiciosAdmin";
import SubirLibro from "@pages/admin/SubirLibro";

// === Oficina ===
import AdminDashboard from "@pages/oficina/AdminDashboard";
import ArticuloBlog from "@pages/oficina/ArticuloBlog";
import BannerUpgrade from "@pages/oficina/BannerUpgrade";
import Biblioteca from "@pages/oficina/Biblioteca";
import BibliotecaConLoginModal from "@pages/oficina/BibliotecaConLoginModal";
import Bienvenida from "@pages/oficina/Bienvenida";

export default function OficinaVirtualRoutes() {
  return (
    <Routes>
      {/* Configuración */}
      <Route path="/configuracion" element={<PanelConfiguracionOficina />} />

      {/* Pagos */}
      <Route path="/pagos" element={<PagoPRO />} />
      <Route path="/pagos/historial" element={<HistorialPagos />} />
      <Route path="/pagos/upgrade" element={<ExitUpgrade />} />

      {/* Noticias */}
      <Route path="/noticias" element={<Noticias />} />

      {/* Admin */}
      <Route path="/admin/consultas" element={<ConsultasAdmin />} />
      <Route path="/admin/dashboard" element={<DashboardAdmin />} />
      <Route path="/admin/login" element={<LoginAdmin />} />
      <Route path="/admin/articulos" element={<PublicarArticulo />} />
      <Route path="/admin/servicios" element={<ServiciosAdmin />} />
      <Route path="/admin/subir-libro" element={<SubirLibro />} />

      {/* Oficina */}
      <Route path="/oficina/dashboard" element={<AdminDashboard />} />
      <Route path="/oficina/articulos" element={<ArticuloBlog />} />
      <Route path="/oficina/upgrade" element={<BannerUpgrade />} />
      <Route path="/oficina/biblioteca" element={<Biblioteca />} />
      <Route path="/oficina/biblioteca-login" element={<BibliotecaConLoginModal />} />
      <Route path="/oficina/bienvenida" element={<Bienvenida />} />

      {/* Ruta por defecto */}
      <Route path="*" element={<Bienvenida />} />
    </Routes>
  );
}
