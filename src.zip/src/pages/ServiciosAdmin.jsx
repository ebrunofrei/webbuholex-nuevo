// src/pages/ServiciosAdmin.jsx
export default function ServiciosAdmin() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-[#b03a1a]">Servicios Admin</h1>
      <p className="mt-2 text-[#4b2e19]">Gestión de servicios jurídicos (placeholder).</p>
    </div>
  );
}
