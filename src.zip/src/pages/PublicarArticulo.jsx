// src/pages/PublicarArticulo.jsx
export default function PublicarArticulo() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-[#b03a1a]">Publicar Artículo</h1>
      <p className="mt-2 text-[#4b2e19]">Editor de artículos jurídicos (placeholder).</p>
    </div>
  );
}
