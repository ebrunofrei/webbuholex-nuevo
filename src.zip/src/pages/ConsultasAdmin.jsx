// src/pages/ConsultasAdmin.jsx
export default function ConsultasAdmin() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-[#b03a1a]">Consultas Admin</h1>
      <p className="mt-2 text-[#4b2e19]">Gestión de consultas de usuarios (placeholder).</p>
    </div>
  );
}
