// src/pages/LoginAdmin.jsx
export default function LoginAdmin() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-2xl font-bold text-[#b03a1a]">Login Admin</h1>
      <p className="text-[#4b2e19]">Placeholder de la vista de login para administradores.</p>
    </div>
  );
}
