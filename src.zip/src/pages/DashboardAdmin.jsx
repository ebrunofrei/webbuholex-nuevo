// src/pages/DashboardAdmin.jsx
export default function DashboardAdmin() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-[#b03a1a]">Panel de Administración</h1>
      <p className="mt-2 text-[#4b2e19]">Aquí irá el dashboard administrativo.</p>
    </div>
  );
}
