// src/pages/SubirLibro.jsx
export default function SubirLibro() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-[#b03a1a]">Subir Libro</h1>
      <p className="mt-2 text-[#4b2e19]">Formulario de subida de libros jurídicos (placeholder).</p>
    </div>
  );
}
