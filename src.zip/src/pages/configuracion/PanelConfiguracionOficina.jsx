// src/pages/configuracion/PanelConfiguracionOficina.jsx
export default function PanelConfiguracionOficina() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-[#b03a1a]">
        Configuración de Oficina Virtual
      </h1>
      <p className="text-[#4b2e19] mt-2">
        Aquí podrás personalizar las opciones de tu oficina virtual.
      </p>
    </div>
  );
}
