// src/App.jsx
import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  useLocation,
} from "react-router-dom";

// === CONTEXTOS ===
import { LitisBotChatProvider } from "@/context/LitisBotChatContext";
import { NoticiasProvider } from "@/context/NoticiasContext";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { LitisBotProvider } from "@/context/LitisBotContext";
import { ToastProvider } from "@components/ui/use-toast";
import { GoogleAuthRootProvider } from "@/context/GoogleAuthContext";

// === COMPONENTES GENERALES ===
import Navbar from "@components/ui/Navbar";
import Footer from "@components/Footer";
import RutaPrivada from "@components/RutaPrivada";
import NoticiasSlider from "@components/NoticiasSlider";
import NoticiasBotonFlotante from "@components/ui/NoticiasBotonFlotante";
import ModalLogin from "@components/ModalLogin";
import RecuperarPassword from "@components/RecuperarPassword";
import PersonalizacionView from "@views/PersonalizacionView";

// === LITISBOT ===
import SidebarChats from "@components/SidebarChats";
import LitisBotChatBase from "@components/LitisBotChatBase";

// === OFICINA VIRTUAL ===
import Sidebar from "@components/Sidebar";
import Oficina from "@oficinaPages/Oficina";
import CasillaExpedientes from "@oficinaPages/CasillaExpedientes";
import ExpedienteDetalle from "@oficinaPages/ExpedienteDetalle";
import ExpedienteJudicialDetalle from "@oficinaPages/ExpedienteJudicialDetalle";
import ExpedienteAdministrativoDetalle from "@oficinaPages/ExpedienteAdministrativoDetalle";
import Biblioteca from "@oficinaPages/Biblioteca";
import Agenda from "@oficinaPages/Agenda";
import LitisBotAudienciaPage from "@oficinaPages/LitisBotAudiencia";
import Notificaciones from "@oficinaPages/Notificaciones";
import Perfil from "@oficinaPages/Perfil";
import OficinaVirtualRoutes from "@oficinaRoutes/OficinaVirtualRoutes";
import NoticiasOficina from "@oficinaPages/Noticias";
import HazteConocido from "@oficinaPages/HazteConocido";
import FirmarEscrito from "@oficinaPages/escritorio/FirmarEscrito";
import ConfigurarAlertas from "@oficinaComponents/ConfigurarAlertas";
import CalculadoraLaboral from "@oficinaPages/CalculadoraLaboral";

// === PÁGINAS PÚBLICAS Y ADMIN ===
import Home from "@pages/Home";
import Blog from "@pages/Blog";
import Servicios from "@pages/Servicios";
import Contacto from "@pages/Contacto";
import BibliotecaJ from "@pages/Biblioteca";
import Jurisprudencia from "@pages/Jurisprudencia";
import JurisprudenciaVisorModal from "@components/jurisprudencia/JurisprudenciaVisorModal";
import Codigos from "@pages/Codigos";
import CodigoDetalle from "@pages/CodigoDetalle";
import NoticiasHome from "@pages/Noticias";
import ArticuloBlog from "@pages/ArticuloBlog";
import Nosotros from "@pages/Nosotros";
import LoginAdmin from "@pages/LoginAdmin";
import DashboardAdmin from "@pages/DashboardAdmin";
import SubirLibro from "@pages/SubirLibro";
import ConsultasAdmin from "@pages/ConsultasAdmin";
import PublicarArticulo from "@pages/PublicarArticulo";
import Error404 from "@pages/Error404";
import Login from "@pages/Login";
import MiCuenta from "@pages/MiCuenta";
import HistorialArchivos from "@pages/HistorialArchivos";
import BibliotecaDrive from "@components/BibliotecaDrive";
import LitisBotBubbleChat from "@components/ui/LitisBotBubbleChat";
import PoliticaPrivacidad from "@pages/legal/politica-de-privacidad";
import TerminosCondiciones from "@pages/legal/terminos-y-condiciones";
import AvisoCookies from "@pages/legal/aviso-cookies";
import CookiesBanner from "@components/CookiesBanner";
import PricingPage from "@pages/PricingPage";
import LandingSaaS from "@pages/LandingSaaS";
import ChatTest from "@components/ChatTest";
import ServicioDetalle from "@pages/ServicioDetalle";
import ServiciosAdmin from "@pages/ServiciosAdmin";
import SeedBrandingPage from "@pages/SeedBrandingPage";

// 🔔 Hook centralizado para FCM
import { useFirebaseMessaging } from "@/hooks/useFirebaseMessaging";

// Ícono botón móvil
import { FolderKanban } from "lucide-react";

/* ============================================================
   Layout OficinaVirtual
============================================================ */
function OficinaVirtualLayout({ children }) {
  return (
    <div className="min-h-screen flex">
      <Sidebar />
      <main className="flex-1 bg-gray-50 p-4">{children}</main>
    </div>
  );
}

/* ============================================================
   LitisBot integrado con sidebar + drawer móvil
============================================================ */
function LitisBotPageIntegrada() {
  const [casos, setCasos] = React.useState([]);
  const [casoActivo, setCasoActivo] = React.useState(null);
  const [showModalHerramientas, setShowModalHerramientas] = React.useState(false);
  const [sidebarOpenMobile, setSidebarOpenMobile] = React.useState(false);

  const { user } = useAuth() || {};
  const userInfo = user || { nombre: "Invitado", pro: false };

  // Bloquear scroll en móvil cuando drawer abierto
  React.useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = sidebarOpenMobile ? "hidden" : prev || "";
    return () => {
      document.body.style.overflow = prev || "";
    };
  }, [sidebarOpenMobile]);

  return (
    <div className="flex w-full min-h-screen bg-white" style={{ height: "100vh", overflow: "hidden" }}>
      {/* Sidebar escritorio */}
      <div
        className="h-full hidden lg:flex"
        style={{
          width: "22vw",
          minWidth: 250,
          maxWidth: 350,
          borderRight: "1px solid #f4e6c7",
          background: "#fff",
          flexDirection: "column",
        }}
      >
        <SidebarChats
          casos={casos}
          setCasos={setCasos}
          casoActivo={casoActivo}
          setCasoActivo={setCasoActivo}
          user={userInfo}
          onOpenHerramientas={() => setShowModalHerramientas(true)}
        />
      </div>

      {/* Botón móvil */}
      {!sidebarOpenMobile && (
        <button
          className="lg:hidden fixed left-4 top-4 z-[80] p-3 rounded-full bg-[#5C2E0B] text-white shadow-xl active:scale-95"
          onClick={() => setSidebarOpenMobile(true)}
          aria-label="Abrir lista de casos"
          title="Casos"
        >
          <FolderKanban size={22} />
        </button>
      )}

      {/* Drawer móvil */}
      <div className="lg:hidden">
        <SidebarChats
          casos={casos}
          setCasos={setCasos}
          casoActivo={casoActivo}
          setCasoActivo={setCasoActivo}
          user={userInfo}
          onOpenHerramientas={() => setShowModalHerramientas(true)}
          isOpen={sidebarOpenMobile}
          onCloseSidebar={() => setSidebarOpenMobile(false)}
        />
      </div>

      {/* Chat principal */}
      <div className="flex-1 flex flex-col items-stretch bg-white" style={{ minWidth: 0, height: "100vh", overflowY: "auto" }}>
        <LitisBotChatBase
          user={userInfo}
          casoActivo={casoActivo}
          expedientes={casos}
          showModal={showModalHerramientas}
          setShowModal={setShowModalHerramientas}
        />
      </div>
    </div>
  );
}

/* ============================================================
   Contenido principal (rutas públicas + oficina)
============================================================ */
function AppContent() {
  useFirebaseMessaging((payload) => {
    console.log("📩 Notificación recibida via hook:", payload);
  });

  const { user, loading, abrirLogin } = useAuth() || {};
  const location = useLocation();

  const enOficinaVirtual = /^\/oficinaVirtual(\/|$)/.test(location.pathname);
  const hideNavbar = location.pathname === "/litisbot";
  const mostrarBotonNoticias = location.pathname === "/";

  function BibliotecaProtegida() {
    if (loading) return <div className="text-center mt-16">Verificando acceso...</div>;
    if (!user) {
      return (
        <div className="text-center p-10">
          <p>Inicia sesión para acceder a la Biblioteca Jurídica.</p>
          <button
            onClick={abrirLogin}
            className="bg-[#a52e00] text-white px-4 py-2 rounded shadow"
          >
            Iniciar sesión
          </button>
          <div className="mt-2 text-sm text-center">
            <button
              onClick={() => abrirLogin("recuperar")}
              className="text-blue-700 underline"
            >
              ¿Olvidaste tu contraseña?
            </button>
          </div>
        </div>
      );
    }
    return <BibliotecaJ />;
  }

  return (
    <div className="relative min-h-screen w-full bg-white">
      {/* === Páginas públicas === */}
      {!enOficinaVirtual && (
        <>
          {!hideNavbar && <Navbar />}
          <div className={`flex ${!hideNavbar ? "pt-20" : ""}`}>
            <main className={`flex-1 w-full ${!hideNavbar ? "lg:pr-80" : ""}`}>
              <Routes>
                {/* Públicas */}
                <Route path="/" element={<Home />} />
                <Route path="/oficina" element={<Navigate to="/oficinaVirtual" replace />} />
                <Route path="/servicios" element={<Servicios />} />
                <Route path="/contacto" element={<Contacto />} />
                <Route path="/biblioteca" element={<BibliotecaProtegida />} />
                <Route path="/biblioteca-drive" element={<BibliotecaDrive />} />
                <Route path="/recuperar" element={<RecuperarPassword />} />
                <Route path="/blog" element={<Blog />} />
                <Route path="/blog/:id" element={<ArticuloBlog />} />
                <Route path="/jurisprudencia" element={<Jurisprudencia />} />
                <Route path="/jurisprudencia/visor/:id" element={<JurisprudenciaVisorModal />} />
                <Route path="/codigos" element={<Codigos />} />
                <Route path="/codigos/:id" element={<CodigoDetalle />} />
                <Route path="/noticias" element={<NoticiasHome />} />
                <Route path="/litisbot" element={<LitisBotPageIntegrada />} />
                <Route path="/nosotros" element={<Nosotros />} />
                <Route path="/login" element={<Login />} />
                <Route path="/historial-archivos" element={<HistorialArchivos />} />
                <Route path="/perfil" element={<RutaPrivada><Perfil /></RutaPrivada>} />
                <Route path="/mi-cuenta" element={<RutaPrivada><MiCuenta /></RutaPrivada>} />

                {/* Admin */}
                <Route path="/db/login" element={<LoginAdmin />} />
                <Route path="/db" element={<RutaPrivada redir="/db/login"><DashboardAdmin /></RutaPrivada>} />
                <Route path="/db/libros" element={<RutaPrivada><SubirLibro /></RutaPrivada>} />
                <Route path="/db/consultas" element={<RutaPrivada><ConsultasAdmin /></RutaPrivada>} />
                <Route path="/db/publicar-articulo" element={<RutaPrivada><PublicarArticulo /></RutaPrivada>} />
                <Route path="/db/servicios" element={<ServiciosAdmin />} />

                {/* Extras */}
                <Route path="/oficinaVirtual/personalizacion" element={<PersonalizacionView />} />
                <Route path="/seed-branding" element={<SeedBrandingPage />} />
                <Route path="/legal/politica-de-privacidad" element={<PoliticaPrivacidad />} />
                <Route path="/legal/terminos-y-condiciones" element={<TerminosCondiciones />} />
                <Route path="/legal/aviso-cookies" element={<AvisoCookies />} />
                <Route path="/planes" element={<PricingPage />} />
                <Route path="/landing" element={<LandingSaaS />} />
                <Route path="/chat-test" element={<ChatTest />} />
                <Route path="/servicios/:slug" element={<ServicioDetalle />} />

                {/* Fallback */}
                <Route path="*" element={<Error404 />} />
              </Routes>
            </main>

            {/* Noticias lateral */}
            {!hideNavbar && (
              <>
                <aside className="hidden lg:flex flex-col w-80 h-[calc(100vh-80px)] fixed top-20 right-0 z-40">
                  <NoticiasSlider />
                </aside>
                {mostrarBotonNoticias && (
                  <NoticiasBotonFlotante endpoint="general" titulo="Noticias" />
                )}
              </>
            )}
          </div>

          {!hideNavbar && <Footer />}
          <CookiesBanner />
          <ModalLogin />
        </>
      )}

      {/* === Oficina Virtual === */}
      {enOficinaVirtual && (
        <OficinaVirtualLayout>
          <Routes>
            <Route path="/oficinaVirtual" element={<Oficina />} />
            <Route path="/oficinaVirtual/casilla-expedientes" element={<CasillaExpedientes />} />
            <Route path="/oficinaVirtual/expediente-jud/:id" element={<ExpedienteJudicialDetalle />} />
            <Route path="/oficinaVirtual/expediente-adm/:id" element={<ExpedienteAdministrativoDetalle />} />
            <Route path="/oficinaVirtual/expedientes/:expedienteId" element={<ExpedienteDetalle />} />
            <Route path="/oficinaVirtual/biblioteca" element={<Biblioteca />} />
            <Route path="/oficinaVirtual/agenda" element={<Agenda />} />
            <Route path="/oficinaVirtual/litisbot" element={<LitisBotAudienciaPage />} />
            <Route path="/oficinaVirtual/firmar-escrito" element={<FirmarEscrito />} />
            <Route path="/oficinaVirtual/notificaciones" element={<Notificaciones />} />
            <Route path="/oficinaVirtual/noticias" element={<NoticiasOficina />} />
            <Route path="/oficinaVirtual/perfil" element={<Perfil />} />
            <Route path="/oficinaVirtual/hazte-conocido" element={<HazteConocido />} />
            <Route path="/oficinaVirtual/calculadora-laboral" element={<CalculadoraLaboral />} />
            <Route path="/oficinaVirtual/*" element={<OficinaVirtualRoutes />} />

            {/* Fallback */}
            <Route path="*" element={<Oficina />} />
          </Routes>
        </OficinaVirtualLayout>
      )}
    </div>
  );
}

/* ============================================================
   App root
============================================================ */
export default function App() {
  return (
    <GoogleAuthRootProvider>
      <LitisBotChatProvider>
        <NoticiasProvider>
          <AuthProvider>
            <LitisBotProvider>
              <ToastProvider>
                <Router>
                  <AppContent />
                  <BubbleWithUser />
                </Router>
              </ToastProvider>
            </LitisBotProvider>
          </AuthProvider>
        </NoticiasProvider>
      </LitisBotChatProvider>
    </GoogleAuthRootProvider>
  );
}

/* ============================================================
   Burbuja flotante de LitisBot (oculta en páginas específicas)
============================================================ */
function BubbleWithUser() {
  const { user } = useAuth() || {};
  const location = useLocation();

  const ocultarBurbujas =
    /^\/litisbot(\/|$)/.test(location.pathname) ||
    /^\/oficinaVirtual\/litisbot(\/|$)/.test(location.pathname);

  if (ocultarBurbujas) return null;

  return (
    <LitisBotBubbleChat
      usuarioId={user?.uid || "invitado"}
      pro={!!user?.pro}
    />
  );
}
